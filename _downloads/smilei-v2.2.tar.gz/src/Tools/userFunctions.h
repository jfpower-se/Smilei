#ifndef USERFUNCTIONS_H
#define USERFUNCTIONS_H

class userFunctions {
    
public:

    static double erfinv(double x);
    static double erfinv2(double x);
    
private:
    
    
};
#endif

