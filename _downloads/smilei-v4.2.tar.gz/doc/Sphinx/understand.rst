.. title:: Understand

Understand
==========

.. toctree::

   units
   algorithms
   parallelization
   vectorization
   collisions
   ionization
   radiation_loss
   multiphoton_Breit_Wheeler
   laser_envelope
   relativistic_fields_initialization
